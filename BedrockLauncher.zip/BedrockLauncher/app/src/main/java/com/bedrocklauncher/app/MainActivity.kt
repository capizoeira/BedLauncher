package com.bedrocklauncher.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.util.Locale

/**
 * Launcher simples para o Minecraft Bedrock oficial (Android).
 *
 * - Detecta se o jogo está instalado e mostra a versão.
 * - Abre o jogo.
 * - Importa .mcworld / .mcpack / .mcaddon / .mctemplate e entrega ao Minecraft.
 *
 * Não baixa, não modifica e não distribui o jogo: ele precisa estar instalado.
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var detailText: TextView
    private lateinit var playButton: Button
    private lateinit var storeButton: Button
    private lateinit var importButton: Button
    private lateinit var clearButton: Button
    private lateinit var messageText: TextView

    @Volatile
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    // ------------------------------------------------------------------
    // Estado do jogo
    // ------------------------------------------------------------------

    private fun refreshState() {
        val info = packageInfoOf(GAME_PACKAGE)
        val installed = info != null

        if (info != null) {
            statusText.text = getString(R.string.status_installed)
            statusText.setTextColor(COLOR_GREEN)
            detailText.text = getString(
                R.string.version_fmt,
                info.versionName ?: "?",
                versionCodeOf(info)
            )
        } else {
            statusText.text = getString(R.string.status_missing)
            statusText.setTextColor(COLOR_RED)
            detailText.text = getString(R.string.status_missing_hint)
        }

        storeButton.visibility = if (installed) View.GONE else View.VISIBLE
        setEnabledUi(playButton, installed && !busy)
        setEnabledUi(importButton, installed && !busy)

        val size = importsDir().walkTopDown().filter { it.isFile }.sumOf { it.length() }
        clearButton.text = getString(R.string.clear_fmt, formatSize(size))
        setEnabledUi(clearButton, size > 0 && !busy)
    }

    @Suppress("DEPRECATION")
    private fun packageInfoOf(pkg: String): PackageInfo? = try {
        if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0L))
        } else {
            packageManager.getPackageInfo(pkg, 0)
        }
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(info: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()

    // ------------------------------------------------------------------
    // Ações
    // ------------------------------------------------------------------

    private fun launchGame() {
        val intent = packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
        if (intent == null) {
            showMessage(getString(R.string.status_missing))
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun openStore() {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$GAME_PACKAGE"))
            )
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=$GAME_PACKAGE")
                    )
                )
            } catch (e2: ActivityNotFoundException) {
                showMessage(getString(R.string.error_no_store))
            }
        }
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(intent, REQ_PICK_FILE)
        } catch (e: ActivityNotFoundException) {
            showMessage(getString(R.string.error_no_picker))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_FILE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        importFile(uri)
    }

    /** Copia o arquivo escolhido para o cache (com a extensão correta) e envia ao jogo. */
    private fun importFile(uri: Uri) {
        val name = displayName(uri)
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext !in ALLOWED_EXTENSIONS) {
            showMessage(getString(R.string.error_extension))
            return
        }

        busy = true
        refreshState()
        showMessage(getString(R.string.copying_fmt, name))

        Thread {
            var copied: File? = null
            var failure: String? = null
            try {
                val dir = importsDir()
                dir.listFiles()?.forEach { it.delete() }
                val target = File(dir, safeFileName(name))
                val input = contentResolver.openInputStream(uri)
                    ?: throw IOException("openInputStream retornou null")
                input.use { src ->
                    target.outputStream().use { dst -> src.copyTo(dst) }
                }
                copied = target
            } catch (e: Exception) {
                failure = e.message ?: e.javaClass.simpleName
            }

            runOnUiThread {
                busy = false
                refreshState()
                val file = copied
                if (file != null) {
                    showMessage(getString(R.string.sending_fmt, name))
                    sendToGame(file)
                } else {
                    showMessage(getString(R.string.error_copy_fmt, failure ?: "?"))
                }
            }
        }.start()
    }

    /**
     * Abre o arquivo diretamente no Minecraft (ACTION_VIEW). O URI do FileProvider
     * termina com o nome do arquivo (ex.: .../Meu Mundo.mcworld), que é o que o jogo
     * usa para reconhecer o tipo de conteúdo.
     */
    private fun sendToGame(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        grantUriPermission(GAME_PACKAGE, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, contentResolver.getType(uri))
            setPackage(GAME_PACKAGE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            showMessage(getString(R.string.error_game_rejected))
        }
    }

    private fun clearImports() {
        importsDir().listFiles()?.forEach { it.delete() }
        refreshState()
        showMessage(getString(R.string.cache_cleared))
    }

    // ------------------------------------------------------------------
    // Arquivos
    // ------------------------------------------------------------------

    private fun importsDir(): File = File(cacheDir, "imports").apply { mkdirs() }

    private fun displayName(uri: Uri): String {
        var name: String? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = cursor.getString(idx)
                }
            }
        return name ?: uri.lastPathSegment ?: "arquivo"
    }

    private fun safeFileName(name: String): String {
        val cleaned = name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").trimStart('.')
        return cleaned.take(120).ifEmpty { "importado.mcworld" }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format(Locale.getDefault(), "%.1f GB", bytes / 1073741824.0)
        bytes >= 1L shl 20 -> String.format(Locale.getDefault(), "%.1f MB", bytes / 1048576.0)
        bytes >= 1L shl 10 -> String.format(Locale.getDefault(), "%.0f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    // ------------------------------------------------------------------
    // Interface (montada em código, sem layouts XML)
    // ------------------------------------------------------------------

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(56), dp(24), dp(32))
        }

        root.addView(label(getString(R.string.app_title), 30f, Color.WHITE, bold = true))
        root.addView(
            label(getString(R.string.app_subtitle), 15f, COLOR_MUTED).apply {
                setPadding(0, dp(4), 0, dp(24))
            }
        )

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = GradientDrawable().apply {
                setColor(COLOR_CARD)
                cornerRadius = dp(16).toFloat()
            }
        }
        card.addView(label(getString(R.string.status_title), 13f, COLOR_MUTED))
        statusText = label("", 22f, Color.WHITE, bold = true).apply { setPadding(0, dp(4), 0, 0) }
        detailText = label("", 14f, COLOR_MUTED).apply { setPadding(0, dp(2), 0, 0) }
        card.addView(statusText)
        card.addView(detailText)
        root.addView(card)

        playButton = styledButton(getString(R.string.play), COLOR_GREEN, Color.WHITE) { launchGame() }
        root.addView(playButton)

        storeButton = styledButton(getString(R.string.store), COLOR_SECONDARY, Color.WHITE) { openStore() }
        root.addView(storeButton)

        importButton = styledButton(getString(R.string.import_file), COLOR_SECONDARY, Color.WHITE) { pickFile() }
        root.addView(importButton)
        root.addView(
            label(getString(R.string.import_hint), 12f, COLOR_MUTED).apply {
                setPadding(dp(4), dp(6), 0, 0)
            }
        )

        clearButton = styledButton("", Color.TRANSPARENT, COLOR_MUTED) { clearImports() }
        root.addView(clearButton)

        messageText = label("", 14f, Color.WHITE).apply {
            visibility = View.GONE
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(messageText)

        root.addView(
            label(getString(R.string.footer), 12f, COLOR_MUTED).apply {
                setPadding(0, dp(32), 0, 0)
            }
        )

        return ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(COLOR_BG)
            addView(root)
        }
    }

    private fun showMessage(text: String) {
        messageText.text = text
        messageText.visibility = View.VISIBLE
    }

    private fun setEnabledUi(button: Button, enabled: Boolean) {
        button.isEnabled = enabled
        button.alpha = if (enabled) 1f else 0.4f
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun styledButton(
        text: String,
        fill: Int,
        textColor: Int,
        onClick: () -> Unit
    ): Button = Button(this).apply {
        this.text = text
        setAllCaps(false)
        setTextColor(textColor)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null

        val shape = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(12).toFloat()
        }
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, null)

        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(56)
        ).apply { topMargin = dp(12) }

        setOnClickListener { onClick() }
    }

    companion object {
        /** Pacote do Minecraft Bedrock oficial na Google Play. */
        private const val GAME_PACKAGE = "com.mojang.minecraftpe"
        private const val REQ_PICK_FILE = 1001
        private val ALLOWED_EXTENSIONS = setOf("mcworld", "mcpack", "mcaddon", "mctemplate")

        private val COLOR_BG = Color.parseColor("#161A1D")
        private val COLOR_CARD = Color.parseColor("#22282C")
        private val COLOR_GREEN = Color.parseColor("#5DA130")
        private val COLOR_RED = Color.parseColor("#E0654F")
        private val COLOR_MUTED = Color.parseColor("#9AA5AB")
        private val COLOR_SECONDARY = Color.parseColor("#37424A")
    }
}
