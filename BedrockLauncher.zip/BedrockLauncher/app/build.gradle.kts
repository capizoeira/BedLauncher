plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bedrocklauncher.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bedrocklauncher.app"
        minSdk = 26
        // 34 de propósito: a partir do 35 o Android força o modo "edge-to-edge"
        // e a tela simples deste launcher precisaria tratar os insets das barras.
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
