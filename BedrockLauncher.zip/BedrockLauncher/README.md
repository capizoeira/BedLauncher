# Bedrock Launcher

Launcher simples para o **Minecraft Bedrock oficial** no Android.

## O que faz

- Detecta se o Minecraft Bedrock está instalado e mostra versão e build
- Abre o jogo com um toque
- Importa `.mcworld`, `.mcpack`, `.mcaddon` e `.mctemplate` e entrega ao Minecraft
- Limpa os arquivos temporários de importação
- Atalho para a Play Store quando o jogo não está instalado

## O que NÃO faz

- Não baixa, não modifica e não distribui o jogo. É preciso ter o Minecraft Bedrock oficial instalado (pacote `com.mojang.minecraftpe`).
- Projeto independente, sem vínculo com a Mojang ou a Microsoft.

## Gerar o APK

Requisitos: Android 8.0+ (minSdk 26).

### Opção 1: pelo GitHub (sem computador)

1. Crie um repositório no GitHub e envie todos os arquivos desta pasta (incluindo `.github`).
2. Abra a aba **Actions** e rode **Build APK** (ou faça um commit na branch `main`).
3. Ao terminar, baixe o artefato **BedrockLauncher-apk** (um zip com `app-debug.apk`).

### Opção 2: Android Studio

Abra a pasta, aguarde o sync do Gradle e use **Build > Build APK(s)**.
O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

### Opção 3: linha de comando

Com JDK 17 e o Android SDK (plataforma 35) instalados:

```
./gradlew assembleDebug
```

## Instalar

Copie o `app-debug.apk` para o celular, toque nele e permita a instalação de apps de fontes desconhecidas quando o Android pedir.

## Observações

- O APK de debug é assinado automaticamente com a chave de debug do Android, o que basta para instalar.
- A importação envia o arquivo ao jogo com um `ACTION_VIEW`. Se a sua versão do Minecraft não aceitar o arquivo por esse caminho, o launcher avisa e você pode abrir o arquivo pelo gerenciador de arquivos.

## Estrutura

```
app/src/main/
  AndroidManifest.xml
  java/com/bedrocklauncher/app/MainActivity.kt   # toda a lógica e a interface
  res/                                           # textos, tema, ícone, paths do FileProvider
.github/workflows/build-apk.yml                  # build automático no GitHub
```
